queue/ -test cases for every distinctive execution path
crashes/ -unique test cases taht cause th etested program to receive a fetal signal(e.g.,SIGSEGV,SIGILL,SIGABRT)
hangs/ -unique test cases that cause the tested program to time out
